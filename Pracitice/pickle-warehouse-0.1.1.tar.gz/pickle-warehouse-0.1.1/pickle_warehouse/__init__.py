from pickle_warehouse.warehouse import Warehouse
__version__ = '0.1.1'
__author__ = 'Thomas Levine'
